---@param install_dir string
return function(install_dir)
    return {
        bundle_path = install_dir,
    }
end
