return function()
    return {
        apex_jar_path = vim.fn.expand "$MASON/share/apex-language-server/apex-jorje-lsp.jar",
    }
end
