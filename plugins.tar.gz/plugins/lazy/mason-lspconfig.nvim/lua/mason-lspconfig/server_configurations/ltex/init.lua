return function()
    return {
        cmd = { "ltex-ls" },
    }
end
