return function()
    return {
        cmd = { "raku-navigator", "--stdio" },
    }
end
