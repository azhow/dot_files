# Hillside 46 Custom Keymap

---

## Compilation Command

```sh
qmk compile -kb hillside/46 -km custom3 -e CONVERT_TO=promicro_rp2040
```

## Intro

For easier initial use, this keymap follows the layout of more standard keyboards where possible. It is a starting point for you to tweak over time to suit your preferences better. You can easily customize it with the [QMK configurator](https://config.qmk.fm/#/hillside/46/LAYOUT).

Some of its key features are:

- Numbers and symbols along the top row of their layers for familiarity.
- Comfortable modifier and function or symbol combinations on the non-base layers using modifiers on the home row of the symbol and number/function layers.
- A layer with both navigation and editing keys allows document editing without leaving the layer.
- QWERTY, Colemak-DH and Dvorak base layer options.

## Why no keymap.c

The online configurator provides a straightforward visual way
   to work with a simple layout and uses a .json keymap format.
So this default ```keymap.json``` was created with the online configurator.

If you wish, you can edit the ```keymap.json``` directly in a text editor,  compile it and flash it.

Or, you can use the graphical configurator to edit the keymap. To do that:

- Open the [QMK configurator](https://config.qmk.fm/#/hillside/46/LAYOUT)
- Using the green up arrow button, load the keymap from ```qmk_firmware/keyboards/hillside/46/keymaps/default/keymap.json```
- Make the changes you wish to the layout
- Save the keymap using the green down arrow button.
- Move the downloaded keymap back into your QMK repository 
     at the same location as above.
- Rename it back to keymap.json
- Compile and flash the firmware.

You can combine a .json based keymap with more advanced features
  specified in .c files with a bit more complexity.
For example, see
 [pierrec83's Kyria map](https://github.com/qmk/qmk_firmware/tree/master/keyboards/splitkb/kyria/keymaps/pierrec83).
 

### Pretty Printing
 
The QMK configurator's .json download has only one key per line,
so it is hard to visualize the keymap if editing manually.
If you want, the Hillside git repo has a pretty-printing script for the keymap.json file.
 
As with anything downloaded from the internet, you should take some steps to assure yourself that the script will not harm your computer nor steal your data. The script is short, so reading it should at least convince you it is rearranging and printing the keymap feed to it, not reading any banking data on your computer.
See the [Hillside wiki](https://github.com/mmccoyd/hillside/wiki) for the script.

